<?php
/*
Plugin Name: Kamahra Unique Words
Plugin URI: https://github.com/amenaregal/kamahra-unique-words
Description: Extracts unique words from input text using a custom separator, with real-time processing and clipboard support.
Use the [kamahra_unique_words] shortcode to display the tool on any page or post.
Customize plugin colors from Settings → Kamahra Colors.
Version: 1.0.0-beta
Author: Amena Sajid
Author URI: 
License: GPLv2 or later
Text Domain: kamahra-unique-words
*/


// ✅ Step 1: Register JS and CSS assets
function kamahra_unique_words_register_assets() {
    wp_register_script(
        'unique-words-js',
        plugins_url('assets/unique-words.js', __FILE__),
        array(),
        null,
        true
    );

    wp_register_style(
        'unique-words-css',
        plugins_url('assets/style.css', __FILE__)
    );
}
add_action('init', 'kamahra_unique_words_register_assets');


// ✅ Step 2: Define shortcode and return HTML with dynamic styles + Help Text
function kamahra_unique_words_shortcode() {
    ob_start();

   $bg_color = get_option('kamahra_bg_color', '#FFFFFF');    // White background default
$text_color = get_option('kamahra_text_color', '#000000'); // Black text default
$button_color = get_option('kamahra_button_color', '#007BFF'); // Default blue button

    ?>

    <style>
        #kamahra-unique-words {
            background-color: <?php echo esc_attr($bg_color); ?>;
            color: <?php echo esc_attr($text_color); ?>;
            padding: 1em;
            border-radius: 10px;
        }

        #kamahra-unique-words textarea {
            width: 100%;
            margin-bottom: 1em;
            padding: 0.5em;
            border-radius: 5px;
            border: 1px solid #ccc;
            color: <?php echo esc_attr($text_color); ?>;
        }

        #kuw-output {
            background-color: #fff;
        }

        #kuw-copy-button {
            background-color: <?php echo esc_attr($button_color); ?>;
            color: white;
            padding: 0.5em 1em;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .kuw-label {
            font-weight: bold;
        }

        .kuw-help {
            font-style: italic;
            color: #999999;
            display: block;
            margin: 4px 0 8px 0;
            font-size: 0.9em;
        }

        #kuw-warning {
            display: none;
            color: #cc3300;
            font-size: 0.9em;
            margin-top: -0.5em;
            margin-bottom: 1em;
        }

        .kuw-radio-group {
            margin-bottom: 1em;
        }

        .kuw-radio-group label {
            margin-right: 1em;
        }
    </style>

    <div id="kamahra-unique-words" class="kamahra-plugin-wrapper">

        <!-- ✅ Input Field -->
<label for="kuw-input" class="kuw-label">Input Text</label>
<small class="kuw-help">Paste or type the text you want to analyze.</small>
<textarea id="kuw-input" rows="6" placeholder="Enter your text here..."></textarea>

<!-- ✅ Warning for soft character limit -->
<p id="kuw-warning">Input is too long; performance may be affected.</p>

<!-- ✅ Separator Radio Buttons -->
<label class="kuw-label">Separator</label>
<small class="kuw-help">Choose how words are separated.</small>
<div class="kuw-radio-group">
    <label>
        <input type="radio" name="kuw-separator" value="space" checked> Space
    </label>
    <label>
        <input type="radio" name="kuw-separator" value="newline"> New Line
    </label>
    <label>
        <input type="radio" name="kuw-separator" value="comma"> Comma
    </label>
    <label>
        <input type="radio" name="kuw-separator" value="tab"> Tab
    </label>
</div>


        <!-- ✅ Output Field -->
        <label for="kuw-output" class="kuw-label">Unique Words</label>
        <small class="kuw-help">These are the unique words extracted from your input.</small>
        <textarea id="kuw-output" rows="6" readonly placeholder="Unique words will appear here."></textarea>

        <button id="kuw-copy-button">Copy to Clipboard</button>
            <!--
        <p style="font-size: 0.875rem; color: #999999;">
            Have feedback? 
            <a href="https://forms.gle/ZSDACq5HYx2c23WdA" target="_blank" style="color: #999999; text-decoration: underline;">Let us know</a>.
        </p>
    -->
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('kamahra_unique_words', 'kamahra_unique_words_shortcode');


// ✅ Step 3: Load CSS and JS only if shortcode is used
function kamahra_enqueue_assets() {
    if (!is_singular()) return;

    global $post;
    if (has_shortcode($post->post_content, 'kamahra_unique_words')) {
        wp_enqueue_style('unique-words-css');
        wp_enqueue_script('unique-words-js');
    }
}
add_action('wp_enqueue_scripts', 'kamahra_enqueue_assets');


// ✅ Step 4: Add a settings page to WP admin menu
function kamahra_add_settings_page() {
    add_options_page(
        'Kamahra Unique Words Settings',
        'Kamahra Colors',
        'manage_options',
        'kamahra-unique-words-settings',
        'kamahra_render_settings_page'
    );
}
add_action('admin_menu', 'kamahra_add_settings_page');


// ✅ Step 5: Render the settings page with form
function kamahra_render_settings_page() {
    ?>
    <div class="wrap">
        <h1>Kamahra Unique Words – Color Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('kamahra_settings_group');
            do_settings_sections('kamahra-unique-words-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}


// ✅ Step 6: Register the color picker settings
function kamahra_register_settings() {
    register_setting('kamahra_settings_group', 'kamahra_bg_color');
    register_setting('kamahra_settings_group', 'kamahra_text_color');
    register_setting('kamahra_settings_group', 'kamahra_button_color');

    add_settings_section('kamahra_main_section', '', null, 'kamahra-unique-words-settings');

    add_settings_field(
        'kamahra_bg_color',
        'Background Color',
        function() {
            $value = get_option('kamahra_bg_color', '#F9F7E8');
            echo "<input type='color' name='kamahra_bg_color' value='" . esc_attr($value) . "' />";
        },
        'kamahra-unique-words-settings',
        'kamahra_main_section'
    );

    add_settings_field(
        'kamahra_text_color',
        'Text Color',
        function() {
            $value = get_option('kamahra_text_color', '#1F1F1F');
            echo "<input type='color' name='kamahra_text_color' value='" . esc_attr($value) . "' />";
        },
        'kamahra-unique-words-settings',
        'kamahra_main_section'
    );

    add_settings_field(
        'kamahra_button_color',
        'Button Color',
        function() {
            $value = get_option('kamahra_button_color', '#FF2FB2');
            echo "<input type='color' name='kamahra_button_color' value='" . esc_attr($value) . "' />";
        },
        'kamahra-unique-words-settings',
        'kamahra_main_section'
    );
}
add_action('admin_init', 'kamahra_register_settings');

function kamahra_activate_defaults() {
    add_option('kamahra_bg_color', '#FFFFFF');
    add_option('kamahra_text_color', '#000000');
    add_option('kamahra_button_color', '#007BFF');
}
register_activation_hook(__FILE__, 'kamahra_activate_defaults');
